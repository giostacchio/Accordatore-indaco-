INDACO TUNER - Android

Progetto Android nativo che incorpora l'accordatore HTML offline.
Il microfono viene richiesto direttamente dall'app.

Per ottenere l'APK:
1. Aprire questa cartella con Android Studio.
2. Attendere il Gradle Sync.
3. Menu Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. L'APK debug viene creato in app/build/outputs/apk/debug/app-debug.apk.

Pacchetto: it.indaco.tuner
Versione: 1.0
Min Android: 8.0 (API 26)
